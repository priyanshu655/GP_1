using Npgsql;

namespace GP_1.Core
{
    internal static class Database
    {
        internal const string ConnectionString = "Server=localhost;Port=5432;Database=MoneyMap;Username=postgres;Password=Deep@1710";

        internal static NpgsqlConnection CreateConnection()
        {
            return new NpgsqlConnection(ConnectionString);
        }
    }
}

