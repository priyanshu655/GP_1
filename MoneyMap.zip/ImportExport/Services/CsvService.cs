using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using Npgsql;
using PdfSharp.Drawing;
using PdfSharp.Pdf;

namespace GP_1.ImportExport.Services
{
    /// <summary>
    /// Summary returned after an import operation.
    /// </summary>
    public class CsvImportResult
    {
        public int TotalRows { get; set; }
        public int SuccessCount { get; set; }
        public int FailedCount { get; set; }
        public List<string> Errors { get; set; } = new List<string>();
    }

    /// <summary>
    /// Handles CSV Import/Export for transaction records.
    /// CSV format: c_user_id,c_category_id,c_transaction_date,c_description,c_amount
    /// </summary>
    public class CsvService
    {
        private readonly string _connectionString;

        public CsvService(string? connectionString = null)
        {
            _connectionString = string.IsNullOrWhiteSpace(connectionString)
                ? Database.ConnectionString
                : connectionString;
        }

        /// <summary>
        /// Exports transactions to a CSV file.
        /// If userId is specified, exports only that user's records.
        /// </summary>
        public int ExportTransactions(string filePath, int? userId = null, DateTime? fromDate = null, DateTime? toDate = null, string typeFilter = "All")
        {
            string strQuery = @"
                SELECT t.c_user_id,
                       t.c_category_id,
                       t.c_transaction_date,
                       t.c_description,
                       t.c_amount
                FROM t_transaction t
                JOIN t_category c ON t.c_category_id = c.c_category_id
                JOIN t_transaction_type tt ON c.c_type_id = tt.c_type_id
                WHERE 1=1";

            if (userId.HasValue && userId.Value > 0)
            {
                strQuery += " AND t.c_user_id = @userId";
            }

            if (fromDate.HasValue)
            {
                strQuery += " AND t.c_transaction_date >= @fromDate";
            }

            if (toDate.HasValue)
            {
                strQuery += " AND t.c_transaction_date <= @toDate";
            }

            if (!string.IsNullOrEmpty(typeFilter) && typeFilter != "All")
            {
                strQuery += " AND tt.c_type_name = @typeFilter";
            }

            strQuery += " ORDER BY t.c_transaction_date DESC, t.c_transaction_id DESC;";

            int rowCount = 0;

            using (StreamWriter writer = new StreamWriter(filePath, false, Encoding.UTF8))
            {
                writer.WriteLine("c_user_id,c_category_id,c_transaction_date,c_description,c_amount");

                using (NpgsqlConnection conn = new NpgsqlConnection(_connectionString))
                using (NpgsqlCommand cmd = new NpgsqlCommand(strQuery, conn))
                {
                    if (userId.HasValue && userId.Value > 0)
                    {
                        cmd.Parameters.AddWithValue("userId", userId.Value);
                    }

                    if (fromDate.HasValue)
                    {
                        cmd.Parameters.AddWithValue("fromDate", fromDate.Value.Date);
                    }

                    if (toDate.HasValue)
                    {
                        cmd.Parameters.AddWithValue("toDate", toDate.Value.Date.AddDays(1).AddTicks(-1));
                    }

                    if (!string.IsNullOrEmpty(typeFilter) && typeFilter != "All")
                    {
                        cmd.Parameters.AddWithValue("typeFilter", typeFilter);
                    }

                    conn.Open();

                    using (NpgsqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string uid = reader["c_user_id"].ToString() ?? "";
                            string cid = reader["c_category_id"].ToString() ?? "";

                            string dateStr;
                            if (reader["c_transaction_date"] is DateOnly dOnly)
                            {
                                dateStr = dOnly.ToString("yyyy-MM-dd");
                            }
                            else if (reader["c_transaction_date"] is DateTime dt)
                            {
                                dateStr = dt.ToString("yyyy-MM-dd");
                            }
                            else
                            {
                                dateStr = reader["c_transaction_date"]?.ToString() ?? "";
                            }

                            string desc = EscapeCsvField(reader["c_description"]?.ToString() ?? "");
                            string amount = Convert.ToDecimal(reader["c_amount"]).ToString("0.00", CultureInfo.InvariantCulture);

                            writer.WriteLine($"{uid},{cid},{dateStr},{desc},{amount}");
                            rowCount++;
                        }
                    }
                }
            }

            return rowCount;
        }

        /// <summary>Creates a printable PDF report using the same filters as CSV export.</summary>
        public int ExportTransactionsPdf(string filePath, int? userId = null, DateTime? fromDate = null, DateTime? toDate = null, string typeFilter = "All")
        {
            string sql = @"SELECT t.c_transaction_date, tt.c_type_name, c.c_category_name, t.c_description, t.c_amount
                           FROM t_transaction t
                           JOIN t_category c ON t.c_category_id = c.c_category_id
                           JOIN t_transaction_type tt ON c.c_type_id = tt.c_type_id
                           WHERE (@userId IS NULL OR t.c_user_id = @userId)
                             AND (@fromDate IS NULL OR t.c_transaction_date >= @fromDate)
                             AND (@toDate IS NULL OR t.c_transaction_date <= @toDate)
                             AND (@typeFilter = 'All' OR tt.c_type_name = @typeFilter)
                           ORDER BY t.c_transaction_date DESC, t.c_transaction_id DESC";

            using var document = new PdfDocument();
            PdfPage page = document.AddPage();
            XGraphics graphics = XGraphics.FromPdfPage(page);
            XFont titleFont = new XFont("Arial", 16);
            XFont headerFont = new XFont("Arial", 9);
            XFont rowFont = new XFont("Arial", 8);
            int y = 40;
            int count = 0;

            void StartPage(bool includeTitle)
            {
                if (!includeTitle)
                {
                    page = document.AddPage();
                    graphics.Dispose();
                    graphics = XGraphics.FromPdfPage(page);
                }
                y = 40;
                graphics.DrawString("MoneyMap Transaction Report", titleFont, XBrushes.Black, 40, y);
                y += 24;
                graphics.DrawString($"Period: {fromDate?.ToString("d") ?? "All"} - {toDate?.ToString("d") ?? "All"}    Type: {typeFilter}", headerFont, XBrushes.DimGray, 40, y);
                y += 24;
                graphics.DrawString("DATE", headerFont, XBrushes.Black, 40, y);
                graphics.DrawString("TYPE", headerFont, XBrushes.Black, 105, y);
                graphics.DrawString("CATEGORY", headerFont, XBrushes.Black, 160, y);
                graphics.DrawString("DESCRIPTION", headerFont, XBrushes.Black, 260, y);
                graphics.DrawString("AMOUNT", headerFont, XBrushes.Black, 465, y);
                y += 14;
                graphics.DrawLine(XPens.LightGray, 40, y, 555, y);
                y += 14;
            }

            StartPage(true);
            using var conn = new NpgsqlConnection(_connectionString);
            using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("userId", (object?)userId ?? DBNull.Value);
            cmd.Parameters.AddWithValue("fromDate", (object?)fromDate?.Date ?? DBNull.Value);
            cmd.Parameters.AddWithValue("toDate", (object?)toDate?.Date ?? DBNull.Value);
            cmd.Parameters.AddWithValue("typeFilter", typeFilter);
            conn.Open();
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                if (y > page.Height.Point - 40) StartPage(false);
                string date = reader.GetValue(0).ToString() ?? string.Empty;
                string type = reader.GetString(1);
                string category = reader.GetString(2);
                string description = reader.GetString(3);
                string amount = Convert.ToDecimal(reader.GetValue(4)).ToString("N2", CultureInfo.InvariantCulture);
                graphics.DrawString(date.Length > 10 ? date[..10] : date, rowFont, XBrushes.Black, 40, y);
                graphics.DrawString(type, rowFont, XBrushes.Black, 105, y);
                graphics.DrawString(category.Length > 16 ? category[..16] : category, rowFont, XBrushes.Black, 160, y);
                graphics.DrawString(description.Length > 34 ? description[..34] : description, rowFont, XBrushes.Black, 260, y);
                graphics.DrawString(amount, rowFont, XBrushes.Black, 465, y);
                y += 15;
                count++;
            }
            document.Save(filePath);
            return count;
        }

        /// <summary>
        /// Imports transactions from a CSV file into PostgreSQL database.
        /// </summary>
        public CsvImportResult ImportTransactions(string filePath, int? fallbackUserId = null)
        {
            CsvImportResult result = new CsvImportResult();

            if (!File.Exists(filePath))
            {
                result.Errors.Add("The selected file does not exist.");
                return result;
            }

            string[] lines = File.ReadAllLines(filePath, Encoding.UTF8);

            if (lines.Length <= 1)
            {
                return result;
            }

            using (NpgsqlConnection conn = new NpgsqlConnection(_connectionString))
            {
                conn.Open();

                // Skip header row (index 0)
                for (int i = 1; i < lines.Length; i++)
                {
                    string line = lines[i];

                    if (string.IsNullOrWhiteSpace(line))
                    {
                        continue;
                    }

                    result.TotalRows++;
                    int rowNumber = i + 1;

                    try
                    {
                        string[] fields = ParseCsvLine(line);

                        if (fields.Length < 5)
                        {
                            throw new FormatException($"Row {rowNumber}: Must have 5 columns (c_user_id, c_category_id, c_transaction_date, c_description, c_amount).");
                        }

                        int userId;
                        if (!int.TryParse(fields[0].Trim(), out userId))
                        {
                            if (fallbackUserId.HasValue && fallbackUserId.Value > 0)
                            {
                                userId = fallbackUserId.Value;
                            }
                            else
                            {
                                throw new FormatException($"Row {rowNumber}: Invalid User ID '{fields[0]}'. Only integer numbers are allowed.");
                            }
                        }

                        if (!int.TryParse(fields[1].Trim(), out int categoryId))
                        {
                            throw new FormatException($"Row {rowNumber}: Invalid Category ID '{fields[1]}'. Only integer numbers are allowed.");
                        }

                        DateOnly transactionDate;
                        string rawDate = fields[2].Trim();
                        string[] dateFormats = { "yyyy-MM-dd", "dd-MM-yyyy", "MM/dd/yyyy", "yyyy/MM/dd", "dd/MM/yyyy" };

                        if (!DateOnly.TryParseExact(rawDate, dateFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out transactionDate))
                        {
                            if (!DateOnly.TryParse(rawDate, out transactionDate))
                            {
                                throw new FormatException($"Row {rowNumber}: Invalid transaction date '{rawDate}' (supported: yyyy-MM-dd or dd-MM-yyyy).");
                            }
                        }

                        string description = fields[3].Trim();

                        if (string.IsNullOrWhiteSpace(description))
                        {
                            throw new FormatException($"Row {rowNumber}: Description cannot be empty.");
                        }

                        if (description.Length > 255)
                        {
                            throw new FormatException($"Row {rowNumber}: Description is longer than 255 characters.");
                        }

                        if (!decimal.TryParse(fields[4].Trim(), NumberStyles.Number, CultureInfo.InvariantCulture, out decimal amount))
                        {
                            throw new FormatException($"Row {rowNumber}: Invalid amount '{fields[4]}'.");
                        }

                        if (amount <= 0)
                        {
                            throw new FormatException($"Row {rowNumber}: Amount must be greater than zero.");
                        }

                        if (!RecordExists(conn, "t_user", "c_user_id", userId))
                        {
                            throw new FormatException($"Row {rowNumber}: User ID {userId} does not exist in the database.");
                        }

                        if (!RecordExists(conn, "t_category", "c_category_id", categoryId))
                        {
                            throw new FormatException($"Row {rowNumber}: Category ID {categoryId} does not exist in the database.");
                        }

                        InsertTransaction(conn, userId, categoryId, transactionDate, description, amount);

                        result.SuccessCount++;
                    }
                    catch (FormatException ex)
                    {
                        result.FailedCount++;
                        result.Errors.Add(ex.Message);
                    }
                    catch (Exception ex)
                    {
                        result.FailedCount++;
                        result.Errors.Add($"Row {rowNumber}: Failed to save ({ex.Message}).");
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Generates a sample CSV template for the user to fill out.
        /// </summary>
        public void GenerateSampleTemplate(string filePath, int sampleUserId = 1)
        {
            using (StreamWriter writer = new StreamWriter(filePath, false, Encoding.UTF8))
            {
                writer.WriteLine("c_user_id,c_category_id,c_transaction_date,c_description,c_amount");
                writer.WriteLine($"{sampleUserId},1,{DateTime.Today:yyyy-MM-dd},Monthly Salary,50000.00");
                writer.WriteLine($"{sampleUserId},2,{DateTime.Today:yyyy-MM-dd},Grocery Shopping,2500.50");
                writer.WriteLine($"{sampleUserId},3,{DateTime.Today:yyyy-MM-dd},Internet Bill,999.00");
            }
        }

        private bool RecordExists(NpgsqlConnection conn, string tableName, string idColumn, int id)
        {
            string strQuery = $"SELECT {idColumn} FROM {tableName} WHERE {idColumn} = @id LIMIT 1;";

            using (NpgsqlCommand cmd = new NpgsqlCommand(strQuery, conn))
            {
                cmd.Parameters.AddWithValue("id", id);
                return cmd.ExecuteScalar() != null;
            }
        }

        private void InsertTransaction(NpgsqlConnection conn, int userId, int categoryId,
            DateOnly transactionDate, string description, decimal amount)
        {
            string strQuery = @"
                INSERT INTO t_transaction
                    (c_user_id, c_category_id, c_transaction_date, c_description, c_amount, c_created_at)
                VALUES
                    (@userId, @categoryId, @transactionDate, @description, @amount, NOW());";

            using (NpgsqlCommand cmd = new NpgsqlCommand(strQuery, conn))
            {
                cmd.Parameters.AddWithValue("userId", userId);
                cmd.Parameters.AddWithValue("categoryId", categoryId);
                cmd.Parameters.AddWithValue("transactionDate", transactionDate);
                cmd.Parameters.AddWithValue("description", description);
                cmd.Parameters.AddWithValue("amount", amount);
                cmd.ExecuteNonQuery();
            }
        }

        private static string EscapeCsvField(string field)
        {
            if (string.IsNullOrEmpty(field))
            {
                return string.Empty;
            }

            if (field.Contains(",") || field.Contains("\"") || field.Contains("\n") || field.Contains("\r"))
            {
                return "\"" + field.Replace("\"", "\"\"") + "\"";
            }

            return field;
        }

        private static string[] ParseCsvLine(string line)
        {
            List<string> fields = new List<string>();
            StringBuilder current = new StringBuilder();
            bool inQuotes = false;

            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];

                if (inQuotes)
                {
                    if (c == '"')
                    {
                        if (i + 1 < line.Length && line[i + 1] == '"')
                        {
                            current.Append('"');
                            i++;
                        }
                        else
                        {
                            inQuotes = false;
                        }
                    }
                    else
                    {
                        current.Append(c);
                    }
                }
                else
                {
                    if (c == '"')
                    {
                        inQuotes = true;
                    }
                    else if (c == ',')
                    {
                        fields.Add(current.ToString());
                        current.Clear();
                    }
                    else
                    {
                        current.Append(c);
                    }
                }
            }

            fields.Add(current.ToString());

            return fields.ToArray();
        }
    }
}
