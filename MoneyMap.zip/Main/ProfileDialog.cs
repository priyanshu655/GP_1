using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using Npgsql;

namespace GP_1.Main
{
    public class ProfileDialog : Form
    {
        private int _userId;
        private string _username = "";

        private Panel headerPanel;
        private Label lblTitle;
        private PictureBox picAvatar;
        private Label lblUsername;

        private Label lblIdTitle;
        private Label lblIdValue;

        private Label lblStatsTitle;
        private Label lblStatsValue;
        private Label lblTransactionTitle = null!;
        private Label lblTransactionValue = null!;
        private Label lblCreatedTitle = null!;
        private Label lblCreatedValue = null!;

        private Button btnClose;

        public ProfileDialog(int userId)
        {
            _userId = userId;
            InitializeComponent();
            LoadProfileData();
        }

        private void InitializeComponent()
        {
            this.headerPanel = new Panel();
            this.lblTitle = new Label();
            this.picAvatar = new PictureBox();
            this.lblUsername = new Label();
            this.lblIdTitle = new Label();
            this.lblIdValue = new Label();
            this.lblStatsTitle = new Label();
            this.lblStatsValue = new Label();
            this.btnClose = new Button();

            this.SuspendLayout();

            // this
            this.ClientSize = new Size(460, 540);
            this.BackColor = Color.White;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = FormStartPosition.CenterParent;
            this.Text = "User Profile";
            try { if (System.IO.File.Exists("MoneyMap.White.ico")) this.Icon = new Icon("MoneyMap.White.ico"); } catch { }

            // headerPanel
            this.headerPanel.BackColor = Color.FromArgb(39, 174, 96);
            this.headerPanel.Dock = DockStyle.Top;
            this.headerPanel.Height = 120;
            this.headerPanel.Controls.Add(this.lblTitle);

            // lblTitle
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            this.lblTitle.ForeColor = Color.White;
            this.lblTitle.Location = new Point(20, 20);
            this.lblTitle.Text = "My Profile";

            // picAvatar
            this.picAvatar.BackColor = Color.FromArgb(238, 242, 246);
            this.picAvatar.Size = new Size(80, 80);
            this.picAvatar.Location = new Point(135, 80);
            this.picAvatar.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                using (var brush = new SolidBrush(Color.FromArgb(148, 163, 184)))
                {
                    var fmt = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
                    e.Graphics.DrawString(_username.Length > 0 ? _username.Substring(0, 1).ToUpper() : "?",
                        new Font("Segoe UI", 32F, FontStyle.Bold), brush, new Rectangle(0, 0, 80, 80), fmt);
                }
            };

            // lblUsername
            this.lblUsername.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            this.lblUsername.ForeColor = Color.FromArgb(35, 42, 52);
            this.lblUsername.TextAlign = ContentAlignment.MiddleCenter;
            this.lblUsername.Location = new Point(0, 170);
            this.lblUsername.Size = new Size(460, 35);

            // lblIdTitle
            this.lblIdTitle.AutoSize = true;
            this.lblIdTitle.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            this.lblIdTitle.ForeColor = Color.FromArgb(110, 118, 130);
            this.lblIdTitle.Location = new Point(40, 220);
            this.lblIdTitle.Text = "USER ID";

            // lblIdValue
            this.lblIdValue.AutoSize = true;
            this.lblIdValue.Font = new Font("Segoe UI", 12F);
            this.lblIdValue.ForeColor = Color.FromArgb(35, 42, 52);
            this.lblIdValue.Location = new Point(40, 240);

            // lblStatsTitle
            this.lblStatsTitle.AutoSize = true;
            this.lblStatsTitle.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            this.lblStatsTitle.ForeColor = Color.FromArgb(110, 118, 130);
            this.lblStatsTitle.Location = new Point(40, 280);
            this.lblStatsTitle.Text = "ACCOUNT BALANCE";

            // lblStatsValue
            this.lblStatsValue.AutoSize = true;
            this.lblStatsValue.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            this.lblStatsValue.ForeColor = Color.FromArgb(39, 174, 96);
            this.lblStatsValue.Location = new Point(40, 300);

            this.lblTransactionTitle = new Label { AutoSize = true, Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold), ForeColor = Color.FromArgb(110, 118, 130), Location = new Point(200, 220), Text = "TOTAL TRANSACTIONS" };
            this.lblTransactionValue = new Label { AutoSize = true, Font = new Font("Segoe UI", 12F), ForeColor = Color.FromArgb(35, 42, 52), Location = new Point(200, 240) };
            this.lblCreatedTitle = new Label { AutoSize = true, Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold), ForeColor = Color.FromArgb(110, 118, 130), Location = new Point(40, 350), Text = "MEMBER SINCE" };
            this.lblCreatedValue = new Label { AutoSize = true, Font = new Font("Segoe UI", 12F), ForeColor = Color.FromArgb(35, 42, 52), Location = new Point(40, 370), Text = "Not available" };

            // btnClose
            this.btnClose.BackColor = Color.FromArgb(241, 245, 249);
            this.btnClose.FlatStyle = FlatStyle.Flat;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.Font = new Font("Segoe UI Semibold", 9.5F);
            this.btnClose.ForeColor = Color.FromArgb(71, 85, 105);
            this.btnClose.Location = new Point(180, 465);
            this.btnClose.Size = new Size(100, 36);
            this.btnClose.Text = "Close";
            this.btnClose.Click += (s, e) => this.Close();

            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblCreatedValue);
            this.Controls.Add(this.lblCreatedTitle);
            this.Controls.Add(this.lblTransactionValue);
            this.Controls.Add(this.lblTransactionTitle);
            this.Controls.Add(this.lblStatsValue);
            this.Controls.Add(this.lblStatsTitle);
            this.Controls.Add(this.lblIdValue);
            this.Controls.Add(this.lblIdTitle);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.picAvatar);
            this.Controls.Add(this.headerPanel);

            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private void LoadProfileData()
        {
            try
            {
                using (NpgsqlConnection con = Database.CreateConnection())
                {
                    con.Open();
                    using (NpgsqlCommand cmd = new NpgsqlCommand("SELECT c_username FROM t_user WHERE c_user_id = @id;", con))
                    {
                        cmd.Parameters.AddWithValue("id", _userId);
                        var res = cmd.ExecuteScalar();
                        if (res != null) _username = res.ToString() ?? "";
                    }
                }

                lblUsername.Text = _username;
                lblIdValue.Text = $"#{_userId:D4}";

                var svc = new TransactionService();
                var txs = svc.GetTransactionsByUserId(_userId);
                decimal income = 0;
                decimal expense = 0;

                foreach (var t in txs)
                {
                    if (t.TransactionType.Equals("Income", StringComparison.OrdinalIgnoreCase)) income += t.Amount;
                    else expense += t.Amount;
                }

                decimal bal = income - expense;
                lblStatsValue.Text = $"₹{bal:N2}";
                lblTransactionValue.Text = txs.Count.ToString();
                if (bal < 0) lblStatsValue.ForeColor = Color.FromArgb(235, 87, 87);

                using (NpgsqlConnection con = Database.CreateConnection())
                {
                    con.Open();
                    const string createdSql = "SELECT column_name FROM information_schema.columns WHERE table_name = 't_user' AND column_name IN ('c_created_at', 'created_at') LIMIT 1;";
                    using var findColumn = new NpgsqlCommand(createdSql, con);
                    string? column = findColumn.ExecuteScalar()?.ToString();
                    if (!string.IsNullOrWhiteSpace(column))
                    {
                        using var createdCmd = new NpgsqlCommand($"SELECT {column} FROM t_user WHERE c_user_id = @id;", con);
                        createdCmd.Parameters.AddWithValue("id", _userId);
                        if (createdCmd.ExecuteScalar() is DateTime date)
                            lblCreatedValue.Text = date.ToString("dd MMMM yyyy");
                    }
                }
            }
            catch (Exception ex)
            {
                lblUsername.Text = "Unknown User";
                lblStatsValue.Text = "Error loading";
            }
        }
    }
}
