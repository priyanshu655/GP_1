using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Npgsql;

namespace GP_1.Authentication.Forms
{
    public partial class SignupForm : Form
    {
        private readonly string passwordPattern =
            @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$";

        private Button? _btnEye1;
        private Button? _btnEye2;

        public SignupForm()
        {
            InitializeComponent();
            SetupCardStyling();
        }

        private void SetupCardStyling()
        {
            // Set app icon
            try
            {
                if (System.IO.File.Exists("MoneyMap.White.ico"))
                    this.Icon = new System.Drawing.Icon("MoneyMap.White.ico");
            }
            catch { }

            cardPanel.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using var borderPen = new Pen(Color.FromArgb(226, 232, 240), 1.5f);
                Rectangle rect = cardPanel.ClientRectangle;
                rect.Width -= 1;
                rect.Height -= 1;
                e.Graphics.DrawRectangle(borderPen, rect);
            };

            // Add Show/Hide password buttons
            _btnEye1 = CreateEyeButton();
            _btnEye1.Click += (s, e) =>
            {
                textBox2.UseSystemPasswordChar = !textBox2.UseSystemPasswordChar;
                _btnEye1.Text = textBox2.UseSystemPasswordChar ? "Show" : "Hide";
            };

            _btnEye2 = CreateEyeButton();
            _btnEye2.Click += (s, e) =>
            {
                textBox3.UseSystemPasswordChar = !textBox3.UseSystemPasswordChar;
                _btnEye2.Text = textBox3.UseSystemPasswordChar ? "Show" : "Hide";
            };

            cardPanel.Controls.Add(_btnEye1);
            cardPanel.Controls.Add(_btnEye2);
        }

        private Button CreateEyeButton()
        {
            var btn = new Button
            {
                Text = "Show",
                Size = new Size(58, 27),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.White,
                ForeColor = Color.FromArgb(100, 116, 139),
                Cursor = Cursors.Hand,
                Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold),
                TabStop = false
            };
            btn.FlatAppearance.BorderSize = 0;
            return btn;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CenterCard();
            textBox1.Focus();
        }

        private void RightPanel_Resize(object sender, EventArgs e)
        {
            CenterCard();
        }

        private void CenterCard()
        {
            if (rightPanel == null || cardPanel == null)
                return;

            int targetX = Math.Max(20, (rightPanel.ClientSize.Width - cardPanel.Width) / 2);
            int targetY = Math.Max(20, (rightPanel.ClientSize.Height - cardPanel.Height) / 2);

            cardPanel.Location = new Point(targetX, targetY);

            if (_btnEye1 != null && textBox2 != null)
            {
                _btnEye1.Location = new Point(textBox2.Right - _btnEye1.Width - 4, textBox2.Top);
                _btnEye1.BringToFront();
            }
            if (_btnEye2 != null && textBox3 != null)
            {
                _btnEye2.Location = new Point(textBox3.Right - _btnEye2.Width - 4, textBox3.Top);
                _btnEye2.BringToFront();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Login loginForm = new Login();
            loginForm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text.Trim();
            string password = textBox2.Text;
            string confirmPassword = textBox3.Text;

            if (string.IsNullOrWhiteSpace(username))
            {
                ShowWarning("Please enter a username.", "Validation Error");
                textBox1.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                ShowWarning("Please enter a password.", "Validation Error");
                textBox2.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(confirmPassword))
            {
                ShowWarning("Please confirm your password.", "Validation Error");
                textBox3.Focus();
                return;
            }

            if (username.Length < 3)
            {
                ShowWarning("Username must be at least 3 characters.", "Validation Error");

                textBox1.Focus();
                return;
            }

            if (!Regex.IsMatch(password, passwordPattern))
            {
                ShowWarning(
                    "Password must contain:\n\n"
                        + "• At least 8 characters\n"
                        + "• At least 1 uppercase letter\n"
                        + "• At least 1 lowercase letter\n"
                        + "• At least 1 number (0–9)\n"
                        + "• At least 1 special character (@$!%*?&)",
                    "Invalid Password"
                );

                textBox2.Focus();
                return;
            }

            if (password != confirmPassword)
            {
                ShowWarning("Passwords do not match.", "Validation Error");

                textBox3.Clear();
                textBox3.Focus();
                return;
            }

            try
            {
                using (NpgsqlConnection cn = Database.CreateConnection())
                {
                    cn.Open();

                    if (UsernameExists(cn, username))
                    {
                        ShowWarning(
                            "Username already exists. Please choose another.",
                            "Signup Failed"
                        );

                        textBox1.Focus();
                        return;
                    }

                    // Hash password before inserting
                    string hashedPassword = BCrypt.Net.BCrypt.HashPassword(password);
                    InsertUser(cn, username, hashedPassword);
                }

                MessageBox.Show(
                    "Account created successfully!\nPlease login to continue.",
                    "Success",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                Login loginForm = new Login();
                loginForm.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "A database error occurred:\n\n" + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private bool UsernameExists(NpgsqlConnection cn, string username)
        {
            const string sql =
                @"
                SELECT COUNT(*)
                FROM t_user
                WHERE c_username = @username";

            using (NpgsqlCommand cmd = new NpgsqlCommand(sql, cn))
            {
                cmd.Parameters.AddWithValue("@username", username);

                long count = Convert.ToInt64(cmd.ExecuteScalar());

                return count > 0;
            }
        }

        private void InsertUser(NpgsqlConnection cn, string username, string passwordHash)
        {
            const string sql =
                @"
                INSERT INTO t_user
                (
                    c_username,
                    c_password_hash,
                    c_is_active
                )
                VALUES
                (
                    @username,
                    @password,
                    TRUE
                )";

            using (NpgsqlCommand cmd = new NpgsqlCommand(sql, cn))
            {
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", passwordHash);
                cmd.ExecuteNonQuery();
            }
        }

        private static void ShowWarning(string message, string title)
        {
            MessageBox.Show(message, title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
