using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using Npgsql;

namespace GP_1.Authentication.Forms
{
    public partial class Login : Form
    {
        public int LoggedInUserId { get; private set; } = -1;

        public Login()
        {
            InitializeComponent();
            SetupCardStyling();
        }

        private void SetupCardStyling()
        {
            // Set app icon
            try
            {
                if (System.IO.File.Exists("MoneyMap.White.ico"))
                    this.Icon = new System.Drawing.Icon("MoneyMap.White.ico");
            }
            catch { }

            cardPanel.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using var borderPen = new Pen(Color.FromArgb(226, 232, 240), 1.5f);
                Rectangle rect = cardPanel.ClientRectangle;
                rect.Width -= 1;
                rect.Height -= 1;
                e.Graphics.DrawRectangle(borderPen, rect);
            };

            // Add Show/Hide password button
            var btnEye = new Button
            {
                Text = "Show",
                Size = new Size(58, 27),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.White,
                ForeColor = Color.FromArgb(100, 116, 139),
                Cursor = Cursors.Hand,
                Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold),
                TabStop = false
            };
            btnEye.FlatAppearance.BorderSize = 0;
            btnEye.Click += BtnEye_Click;

            // Will be positioned in CenterCard once cardPanel is ready
            cardPanel.Controls.Add(btnEye);
            _btnEye = btnEye;
        }

        private Button? _btnEye;

        private void BtnEye_Click(object? sender, EventArgs e)
        {
            textBox2.UseSystemPasswordChar = !textBox2.UseSystemPasswordChar;
            if (_btnEye != null)
                _btnEye.Text = textBox2.UseSystemPasswordChar ? "Show" : "Hide";
        }

        private void Login_Load(object sender, EventArgs e)
        {
            CenterCard();
            textBox1.Focus();
        }

        private void RightPanel_Resize(object sender, EventArgs e)
        {
            CenterCard();
        }

        private void CenterCard()
        {
            if (rightPanel == null || cardPanel == null)
                return;

            int targetX = Math.Max(20, (rightPanel.ClientSize.Width - cardPanel.Width) / 2);
            int targetY = Math.Max(20, (rightPanel.ClientSize.Height - cardPanel.Height) / 2);

            cardPanel.Location = new Point(targetX, targetY);

            // Position eye button to the right of the password textbox
            if (_btnEye != null && textBox2 != null)
            {
                _btnEye.Location = new Point(
                    textBox2.Right - _btnEye.Width - 4,
                    textBox2.Top
                );
                _btnEye.BringToFront();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text.Trim();
            string password = textBox2.Text;

            // 1. Empty checks
            if (string.IsNullOrWhiteSpace(username))
            {
                MessageBox.Show(
                    "Please enter username.",
                    "Validation Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                textBox1.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show(
                    "Please enter password.",
                    "Validation Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                textBox2.Focus();
                return;
            }

            // 2. Database check
            try
            {
                using (NpgsqlConnection con = Database.CreateConnection())
                {
                    con.Open();

                    string sql = @"
                        SELECT c_user_id, c_password_hash
                        FROM t_user 
                        WHERE c_username = @username 
                          AND c_is_active = TRUE;";

                    using (NpgsqlCommand cmd = new NpgsqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@username", username);

                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                int userId = Convert.ToInt32(reader["c_user_id"]);
                                string storedHash = reader["c_password_hash"]?.ToString() ?? "";
                                reader.Close();

                                bool isAuthenticated = false;

                                // Try BCrypt verify first
                                try
                                {
                                    isAuthenticated = BCrypt.Net.BCrypt.Verify(password, storedHash);
                                }
                                catch
                                {
                                    // Stored password might be plain text (legacy) — compare directly
                                    isAuthenticated = (password == storedHash);
                                }

                                if (isAuthenticated)
                                {
                                    // Auto-rehash if password was plain text (not a BCrypt hash)
                                    if (!storedHash.StartsWith("$2"))
                                    {
                                        string newHash = BCrypt.Net.BCrypt.HashPassword(password);
                                        using (NpgsqlCommand updateCmd = new NpgsqlCommand(
                                            "UPDATE t_user SET c_password_hash = @hash WHERE c_user_id = @id", con))
                                        {
                                            updateCmd.Parameters.AddWithValue("@hash", newHash);
                                            updateCmd.Parameters.AddWithValue("@id", userId);
                                            updateCmd.ExecuteNonQuery();
                                        }
                                    }

                                    SessionManager.SaveSession(userId, username);
                                    MainForm mainForm = new MainForm(userId);

                                    this.Hide();
                                    mainForm.ShowDialog();

                                    if (mainForm.LoggedOut)
                                    {
                                        textBox2.Clear();
                                        this.Show();
                                        CenterCard();
                                        textBox2.Focus();
                                    }
                                    else
                                    {
                                        this.Close();
                                    }
                                }
                                else
                                {
                                    MessageBox.Show(
                                        "Invalid username or password.",
                                        "Login Failed",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error
                                    );
                                    textBox2.Clear();
                                    textBox2.Focus();
                                }
                            }
                            else
                            {
                                MessageBox.Show(
                                    "Invalid username or password.",
                                    "Login Failed",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error
                                );
                                textBox2.Clear();
                                textBox2.Focus();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Database error:\n\n" + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SignupForm signupForm = new SignupForm();
            signupForm.Show();
            this.Hide();
        }
    }
}
