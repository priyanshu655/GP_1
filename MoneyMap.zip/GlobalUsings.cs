// Shared project namespaces. Keeping these here prevents a copied import block in every source file.
global using GP_1.Authentication.Forms;
global using GP_1.Budget.Forms;
global using GP_1.Budget.Services;
global using GP_1.Core;
global using GP_1.Home.Forms;
global using GP_1.ImportExport.Forms;
global using GP_1.ImportExport.Services;
global using GP_1.Main;
global using GP_1.Setting.Forms;
global using GP_1.Setting.Services;
global using GP_1.Transaction.Forms;
global using GP_1.Transaction.Models;
global using GP_1.Transaction.Services;
global using GP_1.View;
