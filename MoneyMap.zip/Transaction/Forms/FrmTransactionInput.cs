using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using GP_1.Transaction.Models;
using GP_1.Transaction.Services;

namespace GP_1.Transaction.Forms
{
    public partial class FrmTransactionInput : Form
    {
        private readonly int currentUserId;
        private readonly TransactionService transactionService = new TransactionService();
        private readonly TransactionModel? currentTransaction;

        public bool IsUpdateMode => currentTransaction != null;

        public FrmTransactionInput(int userId)
        {
            InitializeComponent();
            currentUserId = userId;
            SetupStyling();
        }

        public FrmTransactionInput(int userId, TransactionModel transaction)
        {
            InitializeComponent();
            currentUserId = userId;
            currentTransaction = transaction;
            SetupStyling();
        }

        private void SetupStyling()
        {
            try
            {
                if (System.IO.File.Exists("MoneyMap.White.ico"))
                    this.Icon = new System.Drawing.Icon("MoneyMap.White.ico");
            }
            catch { }

            footerPanel.Paint += (s, e) =>
            {
                using (Pen borderPen = new Pen(UITheme.BorderSubtle, 1))
                {
                    e.Graphics.DrawLine(borderPen, 0, 0, footerPanel.Width, 0);
                }
            };

            SetupToolTips();
        }

        private void SetupToolTips()
        {
            ToolTip toolTip = new ToolTip();
            toolTip.SetToolTip(txtDescription, "Enter a short description of the transaction (max 255 chars).");
            toolTip.SetToolTip(nudAmount, "Enter the transaction amount (must be > 0).");
            toolTip.SetToolTip(cmbCategory, "Select an income category.");
            toolTip.SetToolTip(lstCategory, "Select an expense category.");
        }

        private void FrmTransactionInput_Load(object sender, EventArgs e)
        {
            dtpTransactionDate.MaxDate = DateTime.Today.AddDays(365);
            dtpTransactionDate.Value = DateTime.Today;

            if (IsUpdateMode && currentTransaction != null)
            {
                this.Text = "Update Transaction";
                lblTitle.Text = "Update Transaction";
                lblSubtitle.Text = "Modify the existing transaction details";
                btnSave.Text = "Update Transaction";

                if (currentTransaction.TransactionType.Equals("Expense", StringComparison.OrdinalIgnoreCase))
                {
                    rdoExpense.Checked = true;
                }
                else
                {
                    rdoIncome.Checked = true;
                }

                LoadCategories();
                SelectCategoryById(currentTransaction.CategoryId);

                dtpTransactionDate.Value = currentTransaction.TransactionDate;
                txtDescription.Text = currentTransaction.Description;
                nudAmount.Value = Math.Max(nudAmount.Minimum, Math.Min(nudAmount.Maximum, currentTransaction.Amount));
            }
            else
            {
                this.Text = "Add Transaction";
                lblTitle.Text = "Add Transaction";
                lblSubtitle.Text = "Enter your transaction details below";
                btnSave.Text = "Save Transaction";
                rdoIncome.Checked = true;
                LoadCategories();
            }
        }

        private void rdoType_CheckedChanged(object sender, EventArgs e)
        {
            if (sender is RadioButton rdo && rdo.Checked)
            {
                LoadCategories();
            }
        }

        private void LoadCategories()
        {
            bool isIncome = rdoIncome.Checked;
            string typeName = isIncome ? "Income" : "Expense";
            List<TransactionModel> categories = transactionService.GetCategoriesByTypeName(typeName);

            if (isIncome)
            {
                cmbCategory.Visible = true;
                lstCategory.Visible = false;

                cmbCategory.DataSource = null;
                cmbCategory.DisplayMember = "CategoryName";
                cmbCategory.ValueMember = "CategoryId";
                cmbCategory.DataSource = categories;

                if (categories.Count > 0)
                {
                    cmbCategory.SelectedIndex = 0;
                }
            }
            else
            {
                cmbCategory.Visible = false;
                lstCategory.Visible = true;

                lstCategory.DataSource = null;
                lstCategory.DisplayMember = "CategoryName";
                lstCategory.ValueMember = "CategoryId";
                lstCategory.DataSource = categories;

                if (categories.Count > 0)
                {
                    lstCategory.SelectedIndex = 0;
                }
            }
        }

        private void SelectCategoryById(int categoryId)
        {
            if (rdoIncome.Checked && cmbCategory.DataSource is List<TransactionModel> listCmb)
            {
                for (int i = 0; i < listCmb.Count; i++)
                {
                    if (listCmb[i].CategoryId == categoryId)
                    {
                        cmbCategory.SelectedIndex = i;
                        return;
                    }
                }
            }
            else if (!rdoIncome.Checked && lstCategory.DataSource is List<TransactionModel> listLst)
            {
                for (int i = 0; i < listLst.Count; i++)
                {
                    if (listLst[i].CategoryId == categoryId)
                    {
                        lstCategory.SelectedIndex = i;
                        return;
                    }
                }
            }
        }

        private void nudAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '-')
            {
                e.Handled = true;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateInput())
            {
                return;
            }

            TransactionModel? selectedCategory = null;
            if (rdoIncome.Checked)
            {
                selectedCategory = cmbCategory.SelectedItem as TransactionModel;
                if (selectedCategory == null || selectedCategory.CategoryId == 0)
                {
                    MessageBox.Show("Please select an income category.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cmbCategory.Focus();
                    return;
                }
            }
            else
            {
                selectedCategory = lstCategory.SelectedItem as TransactionModel;
                if (selectedCategory == null || selectedCategory.CategoryId == 0)
                {
                    MessageBox.Show("Please select an expense category.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    lstCategory.Focus();
                    return;
                }
            }

            try
            {
                if (IsUpdateMode && currentTransaction != null)
                {
                    TransactionModel transaction = new TransactionModel
                    {
                        TransactionId = currentTransaction.TransactionId,
                        UserId = currentUserId,
                        CategoryId = selectedCategory.CategoryId,
                        TransactionDate = dtpTransactionDate.Value.Date,
                        Description = txtDescription.Text.Trim(),
                        Amount = nudAmount.Value
                    };

                    transactionService.UpdateTransaction(transaction);
                    MessageBox.Show("Transaction updated successfully.", "Success",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    TransactionModel transaction = new TransactionModel
                    {
                        UserId = currentUserId,
                        CategoryId = selectedCategory.CategoryId,
                        TransactionDate = dtpTransactionDate.Value.Date,
                        Description = txtDescription.Text.Trim(),
                        Amount = nudAmount.Value
                    };

                    transactionService.AddTransaction(transaction);

                    // Check if budget limit reached/exceeded for expense
                    if (!rdoIncome.Checked)
                    {
                        var alerts = GP_1.Budget.Services.BudgetService.CheckNewTransactionBudgetAlert(
                            currentUserId,
                            selectedCategory.CategoryId,
                            nudAmount.Value,
                            dtpTransactionDate.Value.Date);

                        if (alerts != null && alerts.Count > 0)
                        {
                            string warningMsg = string.Join("\n\n", alerts);
                            MessageBox.Show(
                                $"Transaction recorded successfully.\n\n{warningMsg}",
                                "Budget Alert Notification",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                        }
                        else
                        {
                            MessageBox.Show("Transaction added successfully.", "Success",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Transaction added successfully.", "Success",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving transaction: " + ex.Message, "Database Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private bool ValidateInput()
        {
            if (nudAmount.Value <= 0)
            {
                MessageBox.Show("Please enter a valid amount greater than 0.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                nudAmount.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtDescription.Text))
            {
                MessageBox.Show("Description is required. Enter a short note so this transaction can also be exported and imported correctly.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtDescription.Focus();
                return false;
            }

            if (txtDescription.Text.Trim().Length > 255)
            {
                MessageBox.Show("Description cannot exceed 255 characters.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtDescription.Focus();
                return false;
            }

            return true;
        }

        private void txtDescription_TextChanged(object sender, EventArgs e)
        {
            int length = txtDescription.Text.Length;
            lblCharCount.Text = $"{length}/255";
            if (length >= 255)
            {
                lblCharCount.ForeColor = Color.Red;
            }
            else
            {
                lblCharCount.ForeColor = Color.FromArgb(148, 163, 184); // Default subtle color
            }
        }

    }
}
