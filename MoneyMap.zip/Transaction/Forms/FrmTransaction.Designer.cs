namespace GP_1.Transaction.Forms
{
    partial class FrmTransaction
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.topPanel = new System.Windows.Forms.Panel();
            this.titleLabel = new System.Windows.Forms.Label();
            this.subtitleLabel = new System.Windows.Forms.Label();
            
            this.lblFromDate = new System.Windows.Forms.Label();
            this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
            this.lblToDate = new System.Windows.Forms.Label();
            this.dtpToDate = new System.Windows.Forms.DateTimePicker();
            
            this.lblRecordId = new System.Windows.Forms.Label();
            this.dudRecordId = new System.Windows.Forms.DomainUpDown();
            
            this.chkListView = new System.Windows.Forms.CheckBox();
            this.listViewTransactions = new System.Windows.Forms.ListView();
            this.picEmptyState = new System.Windows.Forms.PictureBox();
            
            this.searchBox = new System.Windows.Forms.TextBox();
            this.searchLabel = new System.Windows.Forms.Label();
            this.btnInsert = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.statsPanel = new System.Windows.Forms.Panel();
            this.cardTotal = new System.Windows.Forms.Panel();
            this.lblTotalTitle = new System.Windows.Forms.Label();
            this.lblTotalCount = new System.Windows.Forms.Label();
            this.cardIncome = new System.Windows.Forms.Panel();
            this.lblIncomeTitle = new System.Windows.Forms.Label();
            this.lblIncomeSum = new System.Windows.Forms.Label();
            this.cardExpense = new System.Windows.Forms.Panel();
            this.lblExpenseTitle = new System.Windows.Forms.Label();
            this.lblExpenseSum = new System.Windows.Forms.Label();
            this.cardBalance = new System.Windows.Forms.Panel();
            this.lblBalanceTitle = new System.Windows.Forms.Label();
            this.lblBalanceSum = new System.Windows.Forms.Label();
            this.gridPanel = new System.Windows.Forms.Panel();
            this.dgridTransactions = new System.Windows.Forms.DataGridView();
            this.emptyLabel = new System.Windows.Forms.Label();

            this.topPanel.SuspendLayout();
            this.statsPanel.SuspendLayout();
            this.cardTotal.SuspendLayout();
            this.cardIncome.SuspendLayout();
            this.cardExpense.SuspendLayout();
            this.cardBalance.SuspendLayout();
            this.gridPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgridTransactions)).BeginInit();
            this.SuspendLayout();

            // 
            // topPanel
            // 
            this.topPanel.BackColor = System.Drawing.Color.White;
            this.topPanel.Controls.Add(this.titleLabel);
            this.topPanel.Controls.Add(this.subtitleLabel);
            this.topPanel.Controls.Add(this.btnInsert);
            this.topPanel.Controls.Add(this.btnClose);
            this.topPanel.Controls.Add(this.searchBox);
            this.topPanel.Controls.Add(this.searchLabel);
            this.topPanel.Controls.Add(this.lblFromDate);
            this.topPanel.Controls.Add(this.dtpFromDate);
            this.topPanel.Controls.Add(this.lblToDate);
            this.topPanel.Controls.Add(this.dtpToDate);
            this.topPanel.Controls.Add(this.chkListView);
            this.topPanel.Controls.Add(this.lblRecordId);
            this.topPanel.Controls.Add(this.dudRecordId);
            this.topPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.topPanel.Location = new System.Drawing.Point(24, 20);
            this.topPanel.Name = "topPanel";
            this.topPanel.Size = new System.Drawing.Size(950, 195);
            this.topPanel.TabIndex = 0;

            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.titleLabel.ForeColor = System.Drawing.Color.FromArgb(24, 31, 42);
            this.titleLabel.Location = new System.Drawing.Point(0, 8);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(250, 37);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Transactions";

            // 
            // subtitleLabel
            // 
            this.subtitleLabel.AutoSize = true;
            this.subtitleLabel.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.subtitleLabel.ForeColor = System.Drawing.Color.FromArgb(110, 118, 130);
            this.subtitleLabel.Location = new System.Drawing.Point(2, 45);
            this.subtitleLabel.Name = "subtitleLabel";
            this.subtitleLabel.Size = new System.Drawing.Size(350, 21);
            this.subtitleLabel.TabIndex = 1;
            this.subtitleLabel.Text = "Add, modify, and track your financial transactions";

            // 
            // btnInsert
            // 
            this.btnInsert.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnInsert.BackColor = System.Drawing.Color.FromArgb(39, 174, 96);
            this.btnInsert.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInsert.FlatAppearance.BorderSize = 0;
            this.btnInsert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInsert.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnInsert.ForeColor = System.Drawing.Color.White;
            this.btnInsert.Location = new System.Drawing.Point(645, 24);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(155, 36);
            this.btnInsert.TabIndex = 4;
            this.btnInsert.Text = "+ Add Transaction";
            this.btnInsert.UseVisualStyleBackColor = false;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);

            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.White;
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(203, 213, 225);
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105);
            this.btnClose.Location = new System.Drawing.Point(815, 24);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(135, 36);
            this.btnClose.TabIndex = 5;
            this.btnClose.Text = "✕ Close View";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);

            // 
            // searchLabel
            // 
            this.searchLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.searchLabel.AutoSize = true;
            this.searchLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.searchLabel.ForeColor = System.Drawing.Color.FromArgb(110, 118, 130);
            this.searchLabel.Location = new System.Drawing.Point(420, 6);
            this.searchLabel.Name = "searchLabel";
            this.searchLabel.Size = new System.Drawing.Size(59, 20);
            this.searchLabel.TabIndex = 2;
            this.searchLabel.Text = "Search:";

            // 
            // searchBox
            // 
            this.searchBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.searchBox.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.searchBox.Location = new System.Drawing.Point(420, 28);
            this.searchBox.Name = "searchBox";
            this.searchBox.PlaceholderText = "Search category / note...";
            this.searchBox.Size = new System.Drawing.Size(235, 30);
            this.searchBox.TabIndex = 3;
            this.searchBox.TextChanged += new System.EventHandler(this.SearchBox_TextChanged);

            // 
            // lblFromDate
            // 
            this.lblFromDate.AutoSize = true;
            this.lblFromDate.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.lblFromDate.ForeColor = System.Drawing.Color.FromArgb(110, 118, 130);
            this.lblFromDate.Location = new System.Drawing.Point(0, 80);
            this.lblFromDate.Name = "lblFromDate";
            this.lblFromDate.Size = new System.Drawing.Size(49, 20);
            this.lblFromDate.TabIndex = 6;
            this.lblFromDate.Text = "From:";

            // 
            // dtpFromDate
            // 
            this.dtpFromDate.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFromDate.Location = new System.Drawing.Point(50, 76);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.Size = new System.Drawing.Size(120, 29);
            this.dtpFromDate.TabIndex = 7;
            this.dtpFromDate.ValueChanged += new System.EventHandler(this.dtpFilter_ValueChanged);

            // 
            // lblToDate
            // 
            this.lblToDate.AutoSize = true;
            this.lblToDate.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.lblToDate.ForeColor = System.Drawing.Color.FromArgb(110, 118, 130);
            this.lblToDate.Location = new System.Drawing.Point(180, 80);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Size = new System.Drawing.Size(29, 20);
            this.lblToDate.TabIndex = 8;
            this.lblToDate.Text = "To:";

            // 
            // dtpToDate
            // 
            this.dtpToDate.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dtpToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpToDate.Location = new System.Drawing.Point(215, 76);
            this.dtpToDate.Name = "dtpToDate";
            this.dtpToDate.Size = new System.Drawing.Size(120, 29);
            this.dtpToDate.TabIndex = 9;
            this.dtpToDate.ValueChanged += new System.EventHandler(this.dtpFilter_ValueChanged);

            // 
            // chkListView
            // 
            this.chkListView.AutoSize = true;
            this.chkListView.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.chkListView.ForeColor = System.Drawing.Color.FromArgb(110, 118, 130);
            this.chkListView.Location = new System.Drawing.Point(360, 78);
            this.chkListView.Name = "chkListView";
            this.chkListView.Size = new System.Drawing.Size(124, 24);
            this.chkListView.TabIndex = 10;
            this.chkListView.Text = "Use List View";
            this.chkListView.UseVisualStyleBackColor = true;
            this.chkListView.CheckedChanged += new System.EventHandler(this.chkListView_CheckedChanged);

            // 
            // lblRecordId
            // 
            this.lblRecordId.AutoSize = true;
            this.lblRecordId.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.lblRecordId.ForeColor = System.Drawing.Color.FromArgb(110, 118, 130);
            this.lblRecordId.Location = new System.Drawing.Point(500, 80);
            this.lblRecordId.Name = "lblRecordId";
            this.lblRecordId.Size = new System.Drawing.Size(81, 20);
            this.lblRecordId.TabIndex = 11;
            this.lblRecordId.Text = "Record ID:";
            
            // 
            // dudRecordId
            // 
            this.dudRecordId.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dudRecordId.Location = new System.Drawing.Point(585, 76);
            this.dudRecordId.Name = "dudRecordId";
            this.dudRecordId.Size = new System.Drawing.Size(120, 29);
            this.dudRecordId.TabIndex = 12;
            this.dudRecordId.SelectedItemChanged += new System.EventHandler(this.dudRecordId_SelectedItemChanged);

            // 
            // statsPanel
            // 
            this.statsPanel.Controls.Add(this.cardTotal);
            this.statsPanel.Controls.Add(this.cardIncome);
            this.statsPanel.Controls.Add(this.cardExpense);
            this.statsPanel.Controls.Add(this.cardBalance);
            this.statsPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.statsPanel.Location = new System.Drawing.Point(24, 135);
            this.statsPanel.Name = "statsPanel";
            this.statsPanel.Padding = new System.Windows.Forms.Padding(0, 12, 0, 16);
            this.statsPanel.Size = new System.Drawing.Size(950, 95);
            this.statsPanel.TabIndex = 1;
            this.statsPanel.Resize += new System.EventHandler(this.StatsPanel_Resize);

            // 
            // cardTotal
            // 
            this.cardTotal.BackColor = System.Drawing.Color.White;
            this.cardTotal.Controls.Add(this.lblTotalTitle);
            this.cardTotal.Controls.Add(this.lblTotalCount);
            this.cardTotal.Location = new System.Drawing.Point(0, 12);
            this.cardTotal.Name = "cardTotal";
            this.cardTotal.Size = new System.Drawing.Size(220, 68);
            this.cardTotal.TabIndex = 0;

            // 
            // lblTotalTitle
            // 
            this.lblTotalTitle.AutoSize = true;
            this.lblTotalTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 8.5F, System.Drawing.FontStyle.Bold);
            this.lblTotalTitle.ForeColor = System.Drawing.Color.FromArgb(110, 118, 130);
            this.lblTotalTitle.Location = new System.Drawing.Point(14, 10);
            this.lblTotalTitle.Name = "lblTotalTitle";
            this.lblTotalTitle.Size = new System.Drawing.Size(155, 19);
            this.lblTotalTitle.TabIndex = 0;
            this.lblTotalTitle.Text = "TOTAL TRANSACTIONS";

            // 
            // lblTotalCount
            // 
            this.lblTotalCount.AutoSize = true;
            this.lblTotalCount.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.lblTotalCount.ForeColor = System.Drawing.Color.FromArgb(35, 42, 52);
            this.lblTotalCount.Location = new System.Drawing.Point(12, 28);
            this.lblTotalCount.Name = "lblTotalCount";
            this.lblTotalCount.Size = new System.Drawing.Size(29, 35);
            this.lblTotalCount.TabIndex = 1;
            this.lblTotalCount.Text = "0";

            // 
            // cardIncome
            // 
            this.cardIncome.BackColor = System.Drawing.Color.White;
            this.cardIncome.Controls.Add(this.lblIncomeTitle);
            this.cardIncome.Controls.Add(this.lblIncomeSum);
            this.cardIncome.Location = new System.Drawing.Point(235, 12);
            this.cardIncome.Name = "cardIncome";
            this.cardIncome.Size = new System.Drawing.Size(220, 68);
            this.cardIncome.TabIndex = 1;

            // 
            // lblIncomeTitle
            // 
            this.lblIncomeTitle.AutoSize = true;
            this.lblIncomeTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 8.5F, System.Drawing.FontStyle.Bold);
            this.lblIncomeTitle.ForeColor = System.Drawing.Color.FromArgb(39, 174, 96);
            this.lblIncomeTitle.Location = new System.Drawing.Point(14, 10);
            this.lblIncomeTitle.Name = "lblIncomeTitle";
            this.lblIncomeTitle.Size = new System.Drawing.Size(107, 19);
            this.lblIncomeTitle.TabIndex = 0;
            this.lblIncomeTitle.Text = "TOTAL INCOME";

            // 
            // lblIncomeSum
            // 
            this.lblIncomeSum.AutoSize = true;
            this.lblIncomeSum.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.lblIncomeSum.ForeColor = System.Drawing.Color.FromArgb(39, 174, 96);
            this.lblIncomeSum.Location = new System.Drawing.Point(12, 28);
            this.lblIncomeSum.Name = "lblIncomeSum";
            this.lblIncomeSum.Size = new System.Drawing.Size(78, 35);
            this.lblIncomeSum.TabIndex = 1;
            this.lblIncomeSum.Text = "₹0.00";

            // 
            // cardExpense
            // 
            this.cardExpense.BackColor = System.Drawing.Color.White;
            this.cardExpense.Controls.Add(this.lblExpenseTitle);
            this.cardExpense.Controls.Add(this.lblExpenseSum);
            this.cardExpense.Location = new System.Drawing.Point(470, 12);
            this.cardExpense.Name = "cardExpense";
            this.cardExpense.Size = new System.Drawing.Size(220, 68);
            this.cardExpense.TabIndex = 2;

            // 
            // lblExpenseTitle
            // 
            this.lblExpenseTitle.AutoSize = true;
            this.lblExpenseTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 8.5F, System.Drawing.FontStyle.Bold);
            this.lblExpenseTitle.ForeColor = System.Drawing.Color.FromArgb(235, 87, 87);
            this.lblExpenseTitle.Location = new System.Drawing.Point(14, 10);
            this.lblExpenseTitle.Name = "lblExpenseTitle";
            this.lblExpenseTitle.Size = new System.Drawing.Size(117, 19);
            this.lblExpenseTitle.TabIndex = 0;
            this.lblExpenseTitle.Text = "TOTAL EXPENSES";

            // 
            // lblExpenseSum
            // 
            this.lblExpenseSum.AutoSize = true;
            this.lblExpenseSum.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.lblExpenseSum.ForeColor = System.Drawing.Color.FromArgb(235, 87, 87);
            this.lblExpenseSum.Location = new System.Drawing.Point(12, 28);
            this.lblExpenseSum.Name = "lblExpenseSum";
            this.lblExpenseSum.Size = new System.Drawing.Size(78, 35);
            this.lblExpenseSum.TabIndex = 1;
            this.lblExpenseSum.Text = "₹0.00";

            // 
            // cardBalance
            // 
            this.cardBalance.BackColor = System.Drawing.Color.White;
            this.cardBalance.Controls.Add(this.lblBalanceTitle);
            this.cardBalance.Controls.Add(this.lblBalanceSum);
            this.cardBalance.Location = new System.Drawing.Point(705, 12);
            this.cardBalance.Name = "cardBalance";
            this.cardBalance.Size = new System.Drawing.Size(240, 68);
            this.cardBalance.TabIndex = 3;

            // 
            // lblBalanceTitle
            // 
            this.lblBalanceTitle.AutoSize = true;
            this.lblBalanceTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 8.5F, System.Drawing.FontStyle.Bold);
            this.lblBalanceTitle.ForeColor = System.Drawing.Color.FromArgb(41, 128, 185);
            this.lblBalanceTitle.Location = new System.Drawing.Point(14, 10);
            this.lblBalanceTitle.Name = "lblBalanceTitle";
            this.lblBalanceTitle.Size = new System.Drawing.Size(99, 19);
            this.lblBalanceTitle.TabIndex = 0;
            this.lblBalanceTitle.Text = "NET BALANCE";

            // 
            // lblBalanceSum
            // 
            this.lblBalanceSum.AutoSize = true;
            this.lblBalanceSum.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.lblBalanceSum.ForeColor = System.Drawing.Color.FromArgb(41, 128, 185);
            this.lblBalanceSum.Location = new System.Drawing.Point(12, 28);
            this.lblBalanceSum.Name = "lblBalanceSum";
            this.lblBalanceSum.Size = new System.Drawing.Size(78, 35);
            this.lblBalanceSum.TabIndex = 1;
            this.lblBalanceSum.Text = "₹0.00";

            // 
            // gridPanel
            // 
            this.gridPanel.BackColor = System.Drawing.Color.White;
            this.gridPanel.Controls.Add(this.picEmptyState);
            this.gridPanel.Controls.Add(this.emptyLabel);
            this.gridPanel.Controls.Add(this.dgridTransactions);
            this.gridPanel.Controls.Add(this.listViewTransactions);
            this.gridPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridPanel.Location = new System.Drawing.Point(24, 230);
            this.gridPanel.Name = "gridPanel";
            this.gridPanel.Padding = new System.Windows.Forms.Padding(1);
            this.gridPanel.Size = new System.Drawing.Size(950, 370);
            this.gridPanel.TabIndex = 2;

            // 
            // dgridTransactions
            // 
            this.dgridTransactions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgridTransactions.Location = new System.Drawing.Point(1, 1);
            this.dgridTransactions.Name = "dgridTransactions";
            this.dgridTransactions.RowHeadersWidth = 51;
            this.dgridTransactions.Size = new System.Drawing.Size(948, 408);
            this.dgridTransactions.TabIndex = 0;
            this.dgridTransactions.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgridTransactions_CellClick);

            // 
            // emptyLabel
            // 
            this.emptyLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.emptyLabel.AutoSize = true;
            this.emptyLabel.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.emptyLabel.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.emptyLabel.Location = new System.Drawing.Point(360, 180);
            this.emptyLabel.Name = "emptyLabel";
            this.emptyLabel.Size = new System.Drawing.Size(235, 25);
            this.emptyLabel.TabIndex = 1;
            this.emptyLabel.Text = "No transactions found.";
            this.emptyLabel.Visible = false;

            // 
            // picEmptyState
            // 
            this.picEmptyState.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.picEmptyState.Location = new System.Drawing.Point(365, 50);
            this.picEmptyState.Name = "picEmptyState";
            this.picEmptyState.Size = new System.Drawing.Size(220, 130);
            this.picEmptyState.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picEmptyState.TabIndex = 2;
            this.picEmptyState.TabStop = false;
            this.picEmptyState.Visible = false;
            
            // 
            // listViewTransactions
            // 
            this.listViewTransactions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listViewTransactions.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.listViewTransactions.FullRowSelect = true;
            this.listViewTransactions.GridLines = true;
            this.listViewTransactions.Location = new System.Drawing.Point(1, 1);
            this.listViewTransactions.Name = "listViewTransactions";
            this.listViewTransactions.Size = new System.Drawing.Size(948, 368);
            this.listViewTransactions.TabIndex = 3;
            this.listViewTransactions.UseCompatibleStateImageBehavior = false;
            this.listViewTransactions.View = System.Windows.Forms.View.Details;
            this.listViewTransactions.Visible = false;

            // 
            // FrmTransaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(248, 249, 251);
            this.ClientSize = new System.Drawing.Size(998, 620);
            this.Controls.Add(this.gridPanel);
            this.Controls.Add(this.statsPanel);
            this.Controls.Add(this.topPanel);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Name = "FrmTransaction";
            this.Padding = new System.Windows.Forms.Padding(24, 20, 24, 20);
            this.Text = "Transaction Management";
            this.Load += new System.EventHandler(this.FrmTransaction_Load);

            this.topPanel.ResumeLayout(false);
            this.topPanel.PerformLayout();
            this.statsPanel.ResumeLayout(false);
            this.cardTotal.ResumeLayout(false);
            this.cardTotal.PerformLayout();
            this.cardIncome.ResumeLayout(false);
            this.cardIncome.PerformLayout();
            this.cardExpense.ResumeLayout(false);
            this.cardExpense.PerformLayout();
            this.cardBalance.ResumeLayout(false);
            this.cardBalance.PerformLayout();
            this.gridPanel.ResumeLayout(false);
            this.gridPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgridTransactions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEmptyState)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel topPanel;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label subtitleLabel;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox searchBox;
        private System.Windows.Forms.Label searchLabel;
        private System.Windows.Forms.Panel statsPanel;
        private System.Windows.Forms.Panel cardTotal;
        private System.Windows.Forms.Label lblTotalTitle;
        private System.Windows.Forms.Label lblTotalCount;
        private System.Windows.Forms.Panel cardIncome;
        private System.Windows.Forms.Label lblIncomeTitle;
        private System.Windows.Forms.Label lblIncomeSum;
        private System.Windows.Forms.Panel cardExpense;
        private System.Windows.Forms.Label lblExpenseTitle;
        private System.Windows.Forms.Label lblExpenseSum;
        private System.Windows.Forms.Panel cardBalance;
        private System.Windows.Forms.Label lblBalanceTitle;
        private System.Windows.Forms.Label lblBalanceSum;
        private System.Windows.Forms.Panel gridPanel;
        private System.Windows.Forms.DataGridView dgridTransactions;
        private System.Windows.Forms.Label emptyLabel;
        private System.Windows.Forms.Label lblFromDate;
        private System.Windows.Forms.DateTimePicker dtpFromDate;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.DateTimePicker dtpToDate;
        private System.Windows.Forms.CheckBox chkListView;
        private System.Windows.Forms.Label lblRecordId;
        private System.Windows.Forms.DomainUpDown dudRecordId;
        private System.Windows.Forms.PictureBox picEmptyState;
        private System.Windows.Forms.ListView listViewTransactions;
    }
}
